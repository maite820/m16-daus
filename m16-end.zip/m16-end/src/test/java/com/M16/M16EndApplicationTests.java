package com.M16;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class M16EndApplicationTests {

	@Test
	void contextLoads() {
	}

}
