package com.M16.Controller;


import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.M16.Entities.Game;
import com.M16.Entities.Ranking;
import com.M16.Entities.StadisticsUser;
import com.M16.Entities.User;
import com.M16.repository.GameRepository;
import com.M16.repository.UserRepository;

@RestController
@RequestMapping("")
public class GameDAO {
	int idGame = 1;
	@Autowired
	private UserRepository userRepository;

	@Autowired
	private GameRepository gameRepository;

	@GetMapping("/")

	public String iniciar() {

		return "login";
	}

	// 1 POST: /users : crea un jugador
	@PostMapping("/users")
	public String savePlayer(@RequestBody User user) {
	
		userRepository.save(user);
		return "Usuari insertat : " + user.getPwd() + "-" + user.getUser();
	}

	// 2 PUT /users : modifica user

	@PutMapping("/users/{user_id}")
	public String modifUser(@PathVariable("user_id") int user_id, @RequestBody User user) {

		
		if (userRepository.existsById(user_id)) {
			userRepository.save(user);
			return user + " modificat";
		} else {
			return "l' usuari " + user_id + "No modificado";
		}
	}

	// 3 POST /users/{id}/games/ : un jugador especifico realiza una tirada dados
	
	@PostMapping("/players/{usuari_id}/games")
	public String crearGame(@PathVariable("user_id") int user_id, @RequestBody Game game) {

		String ResultatTirada;
		game.setId(idGame);
		game.setId(user_id);
		game.setDado1(((int) (Math.random() * (6 - 1)) + 1));
		game.setDado2(((int) (Math.random() * (6 - 1)) + 1));

		if (game.getDado1() + game.getDado2() == 7) {
			game.setResultado(true);
			ResultatTirada = (game.getDado1() + game.getDado2()) + " :Genial, lo has conseguido";
		} else {
			game.setResultado(false);
			ResultatTirada = (game.getDado1() + game.getDado2()) + " :no lo has conseguido";
		}

		gameRepository.save(game);
		idGame++;
		return ResultatTirada;
	}

	// 4 DELETE /players/{id}/games: elimina tiradas

	@DeleteMapping("/users/{user_id}/games")

	public String eliminaTiradesPlayer(@PathVariable("user_id") int user_id) {

		if (userRepository.findById(user_id) != null && gameRepository.existsGamesByUserId(user_id)) {

			gameRepository.deleteGamesByUserId(user_id);

			return "Partides de l' usuari : " + user_id + " eliminadas";
		} else {

			return "L' ususari seleccionat no te cap partida";
		}

	}

	// 5 . GET /players/: listado por jugador .porcentaje medio exito
	

	@GetMapping("/users")
	public String getAllUser() {

		List<StadisticsUser> allUsersStadistics = new ArrayList<StadisticsUser>();
		List<User> allusers = new ArrayList<User>();
		List<Game> allPartidas = new ArrayList<Game>();

		allusers.addAll(userRepository.findAll());
		for (User u : allusers) {

			allPartidas = gameRepository.findGameByUserId(u.getPwd());
			allUsersStadistics.add(new StadisticsUser(u, allPartidas));
		}
		return allUsersStadistics.toString();

	}

	// 6. GET /players/{id}/games: listado jugadas by jugador

	
	// 7.GET /players/ranking/loser: jugador perdedor
	 
	@GetMapping(value = "/user/rancking/loser")
	public List<User> getListAllGamesRackingLoser() {

		// jugador menos puntos
		List<StadisticsUser> allUsersStadistics = new ArrayList<StadisticsUser>();
		List<User> allusers = new ArrayList<User>();
		List<Game> allPartidas = new ArrayList<Game>();
		Ranking ranking = new Ranking(allUsersStadistics);

		allusers.addAll(userRepository.findAll());
		for (User u : allusers) {

			allPartidas = gameRepository.findGameByUserId(u.getPwd());
			allUsersStadistics.add(new StadisticsUser(u, allPartidas));
		}
		//Ranking ranking = new Ranking(allPlayersStadistics);

		System.out.println(ranking.toString());
		return ranking.getRankingUsersLosters();

	}
	
	//9.GET /players/ranking/winner: MEjor jugador

		 @GetMapping(value="/user/rancking/winner")
		    public List<User> getListAllGamesRackingWinner(){
		         
		         
		        List<StadisticsUser> allUsersStadistics= new ArrayList<StadisticsUser>();
		        List<User> allusers= new ArrayList<User>();
		        List<Game> allPartidas= new ArrayList<Game>();
		        
		        allusers.addAll(userRepository.findAll());
		        for (User u: allusers){
		            
		            allPartidas=gameRepository.findGameByUserId(u.getPwd());
		            allUsersStadistics.add(new StadisticsUser(u, allPartidas));
		        }
		        Ranking ranking= new Ranking(allUsersStadistics);
		        
		       return ranking.getRankingUsersWiners();
	        
	    }
}