package com.M16.View;

public class WebController{
	String host = "http://localhost:8080";
}