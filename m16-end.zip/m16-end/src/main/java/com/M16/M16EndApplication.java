package com.M16;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class M16EndApplication {

	public static void main(String[] args) {
		SpringApplication.run(M16EndApplication.class, args);
	}

}
