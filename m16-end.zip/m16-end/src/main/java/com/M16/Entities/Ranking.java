package com.M16.Entities;



import java.util.ArrayList;
import java.util.List;


public class Ranking {
    private List<StadisticsUser> listaestadistca;
    private List<User> rankingUsersWiners;
    private List<User> rankingUsersLosters;
     
     
    public Ranking(List<StadisticsUser> listaestadistca){
        this.listaestadistca=listaestadistca;
    }

    public List<StadisticsUser> getListaestadistca() {
        return listaestadistca;
    }

    public void setListaestadistca(List<StadisticsUser> listaestadistca) {
        this.listaestadistca = listaestadistca;
    }


    

    public List<User> getRankingUsersWiners() {
        StadisticsUser auxUser;
        List<User> auxList = new ArrayList<User>();

        for (int i = 0; i < listaestadistca.size() - 1; i++) {
            for (int j = i + 1; j < listaestadistca.size() - 1; j++) {
                //he de comparar el elemento actual con el siguiente
                if (listaestadistca.get(i).getPercentatgeExit() < listaestadistca.get(j).getPercentatgeExit()) {
                    auxUser = listaestadistca.get(i);
                        this.listaestadistca.set(i, this.listaestadistca.get(j));
                        this.listaestadistca.set(j, auxUser);

                }
            }
        }

        for (StadisticsUser sp : listaestadistca) {
            if (sp.getPercentatgeExit() != 0) {
                 auxList.add(sp.getUser());
            }
        }

       setRankingUsersLosters(auxList);
        return auxList;
    }

    public void setRankingUsersWiners(List<User> rankingUsersWiners) {
        this.rankingUsersWiners = rankingUsersWiners;
    }

    public List<User> getRankingUsersLosters() {
        StadisticsUser auxUser; 
        List<User> auxList = new ArrayList<User>();
        
        if(listaestadistca!=null){
            for (int i = 0; i < listaestadistca.size() - 1; i++) {
                for (int j = i + 1; j < listaestadistca.size() - 1; j++) {
                    //he de comparar el elemento actual con el siguiente
                    if (listaestadistca.get(i).getPercentatgeFracas() < listaestadistca.get(j).getPercentatgeFracas()) {
                        auxUser = listaestadistca.get(i);
                        this.listaestadistca.set(i, this.listaestadistca.get(j));
                        this.listaestadistca.set(j, auxUser);
                    }
                }
            }
            setListaestadistca(listaestadistca);
        }
        
       
       for (StadisticsUser sp:getListaestadistca()){
           if(sp.getPercentatgeFracas()!=0){
              auxList.add(sp.getUser());
           } 
       }
        setRankingUsersLosters(auxList);
        return auxList;
    }
    
    

    public void setRankingUsersLosters(List<User> rankingUsersLosters) {
        this.rankingUsersLosters = rankingUsersLosters;
    }

	@Override
	public String toString() {
		return "Ranking [listaestadistca=" + listaestadistca + ", rankingUsersWiners=" + rankingUsersWiners
				+ ", rankingUsersLosters=" + rankingUsersLosters + "]";
	}

	
    
    
}