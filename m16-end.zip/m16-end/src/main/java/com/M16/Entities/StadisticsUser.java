package com.M16.Entities;


import java.util.ArrayList;
import java.util.List;


public class StadisticsUser implements IStadisticsPlayer{
    private User user;
    private List<Game> partidasUser= new ArrayList<Game>();
    private double percentatgeExit;
    private double percentatgeFracas;
    private int totalWins;
    private int totalLost;
    private int totalPlays;
    
    public StadisticsUser (User user, List<Game> games){
        this.user=user;
        this.partidasUser=games;
    }
    
    

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public int getTotalWins() {
        return totalWins;
    }

    public void setTotalWins(int totalWins) {
        this.totalWins = totalWins;
    }

    public int getTotalLost() {
        return totalLost;
    }

    public void setTotalLost(int totalLost) {
        this.totalLost = totalLost;
    }

    public int getTotalPlays() {
        return totalPlays;
    }

    public void setTotalPlays(int totalPlays) {
        this.totalPlays = totalPlays;
    }

    public List<Game> getPartidasUser() {
        return partidasUser;
    }

    public void setPartidasUser(List<Game> partidasUser) {
        this.partidasUser = partidasUser;
    }

    public double getPercentatgeExit() {
        return percentatgeExit;
    }

    public void setPercentatgeExit(double percentatgeExit) {
        this.percentatgeExit = percentatgeExit;
    }

    public double getPercentatgeFracas() {
        return percentatgeFracas;
    }

    public void setPercentatgeFracas(double percentatgeFracas) {
        this.percentatgeFracas = percentatgeFracas;
    }
    
    
    
    
    @Override
    public double getpercentatgeWins(List<Game> games) {
        int totalwins=0;
        
        setTotalPlays(games.size());
        
        if(getTotalPlays()>0){
            for(Game p:games){
                if(p.isResultado()==true){
                    totalwins++;
                    setTotalWins(totalwins);
                }
            }
                double averga=((getTotalWins()*100)/getTotalPlays());
                setPercentatgeExit(averga);
            return getPercentatgeExit(); 
        }else{
            return 0;
        }
       
    }
    
    @Override
    public double getpercentatgeLost(List<Game> games) {
         int totallost=0;
        
        setTotalPlays(games.size());
        
        if(getTotalPlays()>0){
            for(Game p:games){
                if(p.isResultado()==false){
                    totallost++;
                    setTotalLost(totallost);
                }
            }
            double average=((getTotalLost()*100)/getTotalPlays());
            setPercentatgeFracas(average);
           return  getPercentatgeFracas();
        }else{
            return 0;
        }
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Estadistiques del jugador=").append(user.getUser());
        sb.append(", partidasPlayer=").append(getPartidasUser().toString());
        sb.append(", percentatge guanyats=").append(getpercentatgeWins(getPartidasUser()));
        sb.append(", percentatge perduts=").append(getpercentatgeLost(getPartidasUser()));
        sb.append(", Total partides jugadess=").append(getTotalPlays());
        sb.append('}');
        sb.append("\n");
        return sb.toString();
    }

    
    
}