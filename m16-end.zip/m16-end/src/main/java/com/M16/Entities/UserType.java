package com.M16.Entities;

public enum  UserType {
	USER,
	ADMIN,
	ANONIMO
}
