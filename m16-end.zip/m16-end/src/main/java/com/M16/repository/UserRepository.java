package com.M16.repository;


import org.springframework.data.mongodb.repository.MongoRepository;

import com.M16.Entities.User;


public interface UserRepository extends MongoRepository<User, Integer> {
	
		

		
	}
