package com.M16.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.M16.Entities.Game;



public interface GameRepository extends MongoRepository<Game, Integer> {
	
	List<Game> findGameByUserId (String userId);
	boolean existsGamesByUserriId(int user_id);
	int deleteGamesByUserId (int user_id);
	boolean existsGamesByUserId(int user_id);
}